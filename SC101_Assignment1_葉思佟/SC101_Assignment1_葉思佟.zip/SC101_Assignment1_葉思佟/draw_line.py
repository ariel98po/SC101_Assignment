"""
File: 
Name:
-------------------------
TODO:
"""

from campy.graphics.gobjects import GOval, GLine
from campy.graphics.gwindow import GWindow
from campy.gui.events.mouse import onmouseclicked


def main():
    from campy.graphics.gobjects import GOval, GLine
from campy.graphics.gwindow import GWindow
from campy.gui.events.mouse import onmouseclicked, onmousemoved

SIZE = 20
hole = 0
window = GWindow()

def main():
    onmouseclicked(hole_puncher)

def hole_puncher(event):
    global hole
    if hole == 0:
        hole = GOval(SIZE, SIZE, x=event.x - SIZE/2, y=event.y - SIZE/2)
        hole.color = 'black'
        window.add(hole)
    else:
        hole2 = GOval(SIZE, SIZE, x=event.x - SIZE/2, y=event.y - SIZE/2)
        line = GLine(hole.x, hole.y, hole2.x, hole2.y)
        window.add(line)
        window.remove(hole)
        hole = 0






if __name__ == '__main__':
	main()
